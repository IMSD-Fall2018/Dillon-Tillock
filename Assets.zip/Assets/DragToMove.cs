﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DragToMove : MonoBehaviour {
    
    public Camera cam;
    public GameObject Player;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        Vector3 screenPosition = Vector3.zero;

        if(Input.GetMouseButton(0)) {
            screenPosition.x = Input.mousePosition.x;
            screenPosition.y = Input.mousePosition.y;
            screenPosition.z = -cam.transform.position.z;
            Debug.Log(screenPosition);

            Player.transform.position = cam.ScreenToWorldPoint(screenPosition);

                 
                    
            }    
		
	}
}
