﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GetData : MonoBehaviour {

    //http://data.nba.net/
    //http://data.nba.net/10s/prod/v1/current/standings_conference.json

    
    //
    //
    //
    public string url = "http://data.nba.net/";
    //
    //
    private IEnumerator Start()
    {

        WWW www = new WWW(url);
        //
        //
        yield return www;

        //
        //
        JSONObject teamData = new JSONObject(www.text);

        JSONObject teamDetails = teamData["sports_content"]["teams"];
        //Debug.Log(teamDetails.ToString());
        //


        //TEAM NAME\\
        string Hawks = teamData["sports_content"]["teams"]["team"][0]["team_nickname"].str;
        // Debug.Log(Hawks.ToString());
        //
        string Celtics = teamData["sports_content"]["teams"]["team"][2]["team_nickname"].str;
        // Debug.Log(Celtics.ToString());
        //
        string Nets = teamData["sports_content"]["teams"]["team"][3]["team_nickname"].str;
        // Debug.Log(Nets.ToString());
        //
        string Hornets = teamData["sports_content"]["teams"]["team"][4]["team_nickname"].str;
        // Debug.Log(Hornets.ToString());
        //
        string Bulls = teamData["sports_content"]["teams"]["team"][5]["team_nickname"].str;
        // Debug.Log(Bulls.ToString());
        //
        string Cavaliers = teamData["sports_content"]["teams"]["team"][6]["team_nickname"].str;
        // Debug.Log(Cavaliers.ToString());
        //
        string Mavericks = teamData["sports_content"]["teams"]["team"][7]["team_nickname"].str;
        // Debug.Log(Mavericks.ToString());
        //
        string Nuggets = teamData["sports_content"]["teams"]["team"][8]["team_nickname"].str;
        // Debug.Log(Nuggets.ToString());
        //
        string Pistons = teamData["sports_content"]["teams"]["team"][9]["team_nickname"].str;
        // Debug.Log(Pistons.ToString());
        //
        string Warriors = teamData["sports_content"]["teams"]["team"][10]["team_nickname"].str;
        // Debug.Log(Warriors.ToString());
        //
        string Rockets = teamData["sports_content"]["teams"]["team"][12]["team_nickname"].str;
        // Debug.Log(Rockets.ToString());
        //
        string Pacers = teamData["sports_content"]["teams"]["team"][13]["team_nickname"].str;
        // Debug.Log(Pacers.ToString());
        //
        string Clippers = teamData["sports_content"]["teams"]["team"][15]["team_nickname"].str;
        // Debug.Log(Clippers.ToString());
        //
        string Lakers = teamData["sports_content"]["teams"]["team"][16]["team_nickname"].str;
        // Debug.Log(Lakers.ToString());
        //
        string Grizzlies = teamData["sports_content"]["teams"]["team"][17]["team_nickname"].str;
        // Debug.Log(Grizzlies.ToString());
        //
        string Heat = teamData["sports_content"]["teams"]["team"][18]["team_nickname"].str;
        // Debug.Log(Heat.ToString());
        //
        string Bucks = teamData["sports_content"]["teams"]["team"][20]["team_nickname"].str;
        // Debug.Log(Bucks.ToString());
        //
        string Timberwolves = teamData["sports_content"]["teams"]["team"][21]["team_nickname"].str;
        // Debug.Log(Timberwolves.ToString());
        //
        string Pelicans = teamData["sports_content"]["teams"]["team"][22]["team_nickname"].str;
        // Debug.Log(Pelicans.ToString());
        //
        string Knicks = teamData["sports_content"]["teams"]["team"][23]["team_nickname"].str;
        // Debug.Log(Knicks.ToString());
        //
        string Thunder = teamData["sports_content"]["teams"]["team"][24]["team_nickname"].str;
        // Debug.Log(Thunder.ToString());
        //
        string Magic = teamData["sports_content"]["teams"]["team"][25]["team_nickname"].str;
        // Debug.Log(Magic.ToString());
        //
        string Sixers = teamData["sports_content"]["teams"]["team"][26]["team_nickname"].str;
        // Debug.Log(Sixers.ToString());
        //
        string Suns = teamData["sports_content"]["teams"]["team"][27]["team_nickname"].str;
        // Debug.Log(Suns.ToString());
        //
        string TrailBlazers = teamData["sports_content"]["teams"]["team"][28]["team_nickname"].str;
        // Debug.Log(TrailBlazers.ToString());
        //
        string Kings = teamData["sports_content"]["teams"]["team"][31]["team_nickname"].str;
        // Debug.Log(Kings.ToString());
        //
        string Spurs = teamData["sports_content"]["teams"]["team"][32]["team_nickname"].str;
        // Debug.Log(Spurs.ToString());
        //
        string Raptors = teamData["sports_content"]["teams"]["team"][33]["team_nickname"].str;
        // Debug.Log(Raptors.ToString());
        //
        string Jazz = teamData["sports_content"]["teams"]["team"][34]["team_nickname"].str;
        // Debug.Log(Jazz.ToString());
        //
        string Wizards = teamData["sports_content"]["teams"]["team"][35]["team_nickname"].str;
        // Debug.Log(Wizards.ToString());

        //
        //
        //
        //
                                 //TEAM CITY\\
        string Atlanta = teamData["sports_content"]["teams"]["team"][0]["team_name"].str;
       // Debug.Log(Atlanta);
        //
        string Boston = teamData["sports_content"]["teams"]["team"][2]["team_name"].str;
       // Debug.Log(Boston);
        //
        string Brooklyn = teamData["sports_content"]["teams"]["team"][3]["team_name"].str;
       // Debug.Log(Brooklyn);
        //
        string Charlotte = teamData["sports_content"]["teams"]["team"][4]["team_name"].str;
       // Debug.Log(Charlotte);
        //
        string Chicago = teamData["sports_content"]["teams"]["team"][5]["team_name"].str;
       // Debug.Log(Chicago);
        //
        string Cleveland = teamData["sports_content"]["teams"]["team"][6]["team_name"].str;
       // Debug.Log(Cleveland);
        //
        string Dallas = teamData["sports_content"]["teams"]["team"][7]["team_name"].str;
       // Debug.Log(Dallas);
        //
        string Denver = teamData["sports_content"]["teams"]["team"][8]["team_name"].str;
       // Debug.Log(Denver);
        //
        string Detroit = teamData["sports_content"]["teams"]["team"][9]["team_name"].str;
       // Debug.Log(Detroit);
        //
        string GoldenState = teamData["sports_content"]["teams"]["team"][10]["team_name"].str;
       // Debug.Log(GoldenState);
        //
        string Huston = teamData["sports_content"]["teams"]["team"][12]["team_name"].str;
       // Debug.Log(Huston);
        //
        string Indiana = teamData["sports_content"]["teams"]["team"][13]["team_name"].str;
      // Debug.Log(Indiana);
        //
        string LosAngelesC = teamData["sports_content"]["teams"]["team"][15]["team_name"].str;
       // Debug.Log(LosAngelesC);
        //
        string losAngelesL = teamData["sports_content"]["teams"]["team"][16]["team_name"].str;
      // Debug.Log(losAngelesL);
        //
        string Memphis = teamData["sports_content"]["teams"]["team"][17]["team_name"].str;
       // Debug.Log(Memphis);
        //
        string Miami = teamData["sports_content"]["teams"]["team"][18]["team_name"].str;
       // Debug.Log(Miami);
        //
        string Milwaukee = teamData["sports_content"]["teams"]["team"][20]["team_name"].str;
       // Debug.Log(Milwaukee);
        //
        string Minnesota = teamData["sports_content"]["teams"]["team"][21]["team_name"].str;
       // Debug.Log(Minnesota);
        //
        string NewOrleans = teamData["sports_content"]["teams"]["team"][22]["team_name"].str;
       // Debug.Log(NewOrleans);
        //
        string NewYork = teamData["sports_content"]["teams"]["team"][23]["team_name"].str;
       // Debug.Log(NewYork);
        //
        string OklahomaCity = teamData["sports_content"]["teams"]["team"][24]["team_name"].str;
       // Debug.Log(OklahomaCity);
        //
        string Orlando = teamData["sports_content"]["teams"]["team"][25]["team_name"].str;
       // Debug.Log(Orlando);
        //
        string Philadelphia = teamData["sports_content"]["teams"]["team"][26]["team_name"].str;
       // Debug.Log(Philadelphia);
        //
        string Phoenix = teamData["sports_content"]["teams"]["team"][27]["team_name"].str;
       // Debug.Log(Phoenix);
        //
        string Portland = teamData["sports_content"]["teams"]["team"][28]["team_name"].str;
       // Debug.Log(Portland);
        //
        string Sacramento = teamData["sports_content"]["teams"]["team"][31]["team_name"].str;
       // Debug.Log(Sacramento);
        //
        string SanAntonio = teamData["sports_content"]["teams"]["team"][32]["team_name"].str;
       // Debug.Log(SanAntonio);
        //
        string Toronto = teamData["sports_content"]["teams"]["team"][33]["team_name"].str;
       // Debug.Log(Toronto);
        //
        string Utah = teamData["sports_content"]["teams"]["team"][34]["team_name"].str;
      // Debug.Log(Utah);
        //
        string Washington = teamData["sports_content"]["teams"]["team"][35]["team_name"].str;
      // Debug.Log(Washington);

        //
        //
        //

                                     //TEAM CONFERENCE\\
        string AtlantaConf = teamData["sports_content"]["teams"]["team"][0]["conference"].str;
       // Debug.Log(Atlanta + " is in the " + AtlantaConf + "ern conference.");
        //
        string BostonConf = teamData["sports_content"]["teams"]["team"][2]["conference"].str;
       // Debug.Log(Boston + " is in the " + BostonConf + "ern conference.");
        //
        string BrooklynConf = teamData["sports_content"]["teams"]["team"][3]["conference"].str;
       // Debug.Log(Brooklyn + " is in the " + BrooklynConf + "ern conference.");
        //
        string CharlotteConf = teamData["sports_content"]["teams"]["team"][4]["conference"].str;
       // Debug.Log(Charlotte + " is in the " + CharlotteConf + "ern conference.");
        //
        string ChicagoConf = teamData["sports_content"]["teams"]["team"][5]["conference"].str;
       // Debug.Log(Chicago + " is in the " + ChicagoConf + "ern conference.");
        //
        string ClevelandConf = teamData["sports_content"]["teams"]["team"][6]["conference"].str;
       // Debug.Log(Cleveland + " is in the " + ClevelandConf + "ern conference.");
        //
        string DallasConf = teamData["sports_content"]["teams"]["team"][7]["conference"].str;
       // Debug.Log(Dallas + " is in the " + DallasConf + "ern conference.");
        //
        string DenverConf = teamData["sports_content"]["teams"]["team"][8]["conference"].str;
       // Debug.Log(Denver + " is in the " + DenverConf + "ern conference.");
        //
        string DetroitConf = teamData["sports_content"]["teams"]["team"][9]["conference"].str;
      // Debug.Log(Detroit + " is in the " + DetroitConf + "ern conference.");
        //
        string GoldenStateConf = teamData["sports_content"]["teams"]["team"][10]["conference"].str;
       // Debug.Log(GoldenState + " is in the " + GoldenStateConf + "ern conference.");
        //
        string HustonConf = teamData["sports_content"]["teams"]["team"][12]["conference"].str;
      // Debug.Log(Huston + " is in the " + HustonConf + "ern conference.");
        //
        string IndianaConf = teamData["sports_content"]["teams"]["team"][13]["conference"].str;
      // Debug.Log(Indiana + " is in the " + IndianaConf + "ern conference.");
        //
        string LosAngelesCConf = teamData["sports_content"]["teams"]["team"][15]["team_name"].str;
       // Debug.Log(LosAngelesC + " is in the " + LosAngelesCConf + "ern conference.");
        //
        string losAngelesLConf = teamData["sports_content"]["teams"]["team"][16]["conference"].str;
       // Debug.Log(losAngelesL + " is in the " + losAngelesLConf + "ern conference.");
        //
        string MemphisConf = teamData["sports_content"]["teams"]["team"][17]["conference"].str;
       // Debug.Log(Memphis + " is in the " + MemphisConf + "ern conference.");
        //
        string MiamiConf = teamData["sports_content"]["teams"]["team"][18]["conference"].str;
       // Debug.Log(Miami + " is in the " + MiamiConf + "ern conference.");
        //
        string MilwaukeeConf = teamData["sports_content"]["teams"]["team"][20]["conference"].str;
       // Debug.Log(Milwaukee + " is in the " + MilwaukeeConf + "ern conference.");
        //
        string MinnesotaConf = teamData["sports_content"]["teams"]["team"][21]["conference"].str;
       // Debug.Log(Minnesota + " is in the " + MinnesotaConf + "ern conference.");
        //
        string NewOrleansConf = teamData["sports_content"]["teams"]["team"][22]["conference"].str;
       // Debug.Log(NewOrleans + " is in the " + NewOrleansConf + "ern conference.");
        //
        string NewYorkConf = teamData["sports_content"]["teams"]["team"][23]["conference"].str;
       // Debug.Log(NewYork + " is in the " + NewYorkConf + "ern conference.");
        //
        string OklahomaCityConf = teamData["sports_content"]["teams"]["team"][24]["conference"].str;
      // Debug.Log(OklahomaCity + " is in the " + OklahomaCityConf + "ern conference.");
        //
        string OrlandoConf = teamData["sports_content"]["teams"]["team"][25]["conference"].str;
       // Debug.Log(Orlando + " is in the " + OrlandoConf + "ern conference.");
        //
        string PhiladelphiaConf = teamData["sports_content"]["teams"]["team"][26]["conference"].str;
       // Debug.Log(Philadelphia + " is in the " + PhiladelphiaConf + "ern conference.");
        //
        string PhoenixConf = teamData["sports_content"]["teams"]["team"][27]["conference"].str;
       // Debug.Log(Phoenix + " is in the " + PhoenixConf + "ern conference.");
        //
        string PortlandConf = teamData["sports_content"]["teams"]["team"][28]["conference"].str;
       // Debug.Log(Portland + " is in the " + PortlandConf + "ern conference.");
        //
        string SacramentoConf = teamData["sports_content"]["teams"]["team"][31]["conference"].str;
      // Debug.Log(Sacramento + " is in the " + SacramentoConf + "ern conference.");
        //
        string SanAntonioConf = teamData["sports_content"]["teams"]["team"][32]["conference"].str;
       // Debug.Log(SanAntonio + " is in the " + SanAntonioConf + "ern conference.");
        //
        string TorontoConf = teamData["sports_content"]["teams"]["team"][33]["conference"].str;
       // Debug.Log(Toronto + " is in the " + TorontoConf + "ern conference.");
        //
        string UtahConf = teamData["sports_content"]["teams"]["team"][34]["conference"].str;
       // Debug.Log(Utah + " is in the " + UtahConf + "ern conference.");
        //
        string WashingtonConf = teamData["sports_content"]["teams"]["team"][35]["conference"].str;
       // Debug.Log(Washington + " is in the " + WashingtonConf + "ern conference.");

        //
        //
        //
                                        //Print Line\\
        string atlantahawks = "The " + Atlanta + " " + Hawks + " are 6-23 in the " + AtlantaConf + "ern conference.";
        Debug.Log(atlantahawks);
        //
        string bostonceltics = "The " + Boston + " " + Celtics + " are 18-11 in the " + BostonConf + "ern conference.";
        Debug.Log(bostonceltics);
        //
        string brooklynnets = "The " + Brooklyn + " " + Nets + " are 13-18 in the " + BrooklynConf + "ern conference.";
        Debug.Log(brooklynnets);
        //
        string charlottehornets = "The " + Charlotte + " " + Hornets + " are 14-15 in the " + CharlotteConf + "ern conference.";
        Debug.Log(charlottehornets);
        //
        string chicagobulls = "The " + Chicago + " " + Bulls + " are 7-23 in the " + ChicagoConf + "ern conference.";
        Debug.Log(chicagobulls);
        //
        string clevelandcavaliers = "The " + Cleveland + " " + Cavaliers + " are 7-23 in the " + ClevelandConf + "ern conference.";
        Debug.Log(clevelandcavaliers);
        //
        string dallasmavericks = "The " + Dallas + " " + Mavericks + " are 15-13 in the " + DallasConf + "ern conference.";
        Debug.Log(dallasmavericks);
        //
        string denvernuggets = "The " + Denver + " " + Nuggets + " are 20-9 in the " + DenverConf + "ern conference.";
        Debug.Log(denvernuggets);
        //
        string detroitpistons = "The " + Detroit + " " + Pistons + " are 14-13 in the " + DetroitConf + "ern conference.";
        Debug.Log(detroitpistons);
        //
        string goldenstatewarriors = "The " + GoldenState + " " + Warriors + " are 20-10 in the " + GoldenStateConf + "ern conference.";
        Debug.Log(goldenstatewarriors);
        //
        string hustonrockets = "The " + Huston + " " + Rockets + " are 14-14 in the " + HustonConf + "ern conference.";
        Debug.Log(hustonrockets);
        //
        string indianapacers = "The " + Indiana + " " + Pacers + " are 12-10 in the " + IndianaConf + "ern conference.";
        Debug.Log(indianapacers);
        //
        string losangelesclippers = "The " + LosAngelesC + " " + Clippers + " are 17-12 in the " + LosAngelesCConf + "ern conference.";
        Debug.Log(losangelesclippers);
        //
        string losangeleslakers = "The " + losAngelesL + " " + Lakers + " are 18-12 in the " + losAngelesLConf + "ern conference.";
        Debug.Log(losangeleslakers);
        //
        string memphisgrizzlies = "The " + Memphis + " " + Grizzlies + " are 16-13 in the " + MemphisConf + "ern conference.";
        Debug.Log(memphisgrizzlies);
        //
        string miamiheat = "The " + Miami + " " + Heat + " are 13-16 in the " + MiamiConf + "ern conference.";
        Debug.Log(miamiheat);
        //
        string milwaukeebucks = "The " + Milwaukee + " " + Bucks + " are 19-9 in the " + MilwaukeeConf + "ern conference.";
        Debug.Log(milwaukeebucks);
        //
        string minnesotatimberwolves = "The " + Minnesota + " " + Timberwolves + " are 13-16 in the " + MinnesotaConf + "ern conference.";
        Debug.Log(minnesotatimberwolves);
        //
        string neworleanspelicans = "The " + NewOrleans + " " + Pelicans + " are 15-16 in the " + NewOrleansConf + "ern conference.";
        Debug.Log(neworleanspelicans);
        //
        string newyorkknicks = "The " + NewYork + " " + Knicks + " are 9-22 in the " + NewYorkConf + "ern conference.";
        Debug.Log(newyorkknicks);
        //
        string oklahomacitythunder = "The " + OklahomaCity + " " + Thunder + " are 18-10 in the " + OklahomaCityConf + "ern conference.";
        Debug.Log(oklahomacitythunder);
        //
        string orlandomagic = "The " + Orlando + " " + Magic + " are 14-15 in the " + OrlandoConf + "ern conference.";
        Debug.Log(orlandomagic);
        //
        string philadelphia76ers = "The " + Philadelphia + " " + Sixers + " are 20-11 in the " + PhiladelphiaConf + "ern conference.";
        Debug.Log(philadelphia76ers);
        //
        string phoenixsuns = "The " + Phoenix + " " + Suns + " are 6-24 in the " + PhoenixConf + "ern conference.";
        Debug.Log(phoenixsuns);
        //
        string portlandtrailblazers = "The " + Portland + " " + TrailBlazers + " are 16-13 in the " + PortlandConf + "ern conference.";
        Debug.Log(portlandtrailblazers);
        //
        string sacramentokings = "The " + Sacramento + " " + Kings + " are 16-13 in the " + SacramentoConf + "ern conference.";
        Debug.Log(sacramentokings);
        //
        string sanantoniospurs = "The " + SanAntonio + " " + Spurs + " are 15-15 in the " + SanAntonioConf + "ern conference.";
        Debug.Log(sanantoniospurs);
        //
        string torontoraptors = "The " + Toronto + " " + Raptors + " are 23-9 in the " + TorontoConf + "ern conference.";
        Debug.Log(torontoraptors);
        //
        string utahjazz = "The " + Utah + " " + Jazz + " are 14-16 in the " + UtahConf + "ern conference.";
        Debug.Log(utahjazz);
        //
        string washingtonwizards = "The " + Washington + " " + Wizards + " are 12-18 in the " + WashingtonConf + "ern conference.";
        Debug.Log(washingtonwizards);
        

            


    }

   
   






}
